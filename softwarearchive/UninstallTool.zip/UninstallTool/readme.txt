This is the portable version of the program, so don't worry about insialling it!
If you would like to install Uninstall Tool go to the "Setup" folder and run "Setup.exe"