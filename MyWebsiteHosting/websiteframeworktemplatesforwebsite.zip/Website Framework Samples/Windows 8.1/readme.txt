Unicode Character to get space in title bar!

 